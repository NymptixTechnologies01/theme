<?php
/**
 * Plugin Name: Template Library Plugin
 * Description: A plugin to manage a library of templates with download functionality.
 * Version: 1.2
 * Author: Your Name
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Register the download handler
function register_download_template() {
    add_rewrite_rule('^download/(.+)$', 'index.php?download_template=$matches[1]', 'top');
}
add_action('init', 'register_download_template');

// Handle the download request
function download_template() {
    if (isset($_GET['download_template'])) {
        $file = basename($_GET['download_template']); // Sanitize the file name
        $filepath = get_template_directory() . '/templates/' . $file; // Path to the file

        // Check if the file exists
        if (file_exists($filepath)) {
            // Set headers to trigger the download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $file . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));

            // Clear output buffer
            ob_clean();
            flush();

            // Read the file and send it to the output
            readfile($filepath);
            exit;
        } else {
            // File doesn't exist
            wp_die('File not found.', 'Error', array('response' => 404));
        }
    }
}
add_action('template_redirect', 'download_template');



// Enqueue styles and scripts
function tlp_enqueue_scripts() {
    wp_enqueue_style('tlp-style', plugin_dir_url(__FILE__) . 'assets/style.css');
}
add_action('admin_enqueue_scripts', 'tlp_enqueue_scripts');

// Create the admin menu
function tlp_create_menu() {
    add_menu_page('Template Library', 'Template Library', 'manage_options', 'template-library', 'tlp_template_library_page');
}
add_action('admin_menu', 'tlp_create_menu');

// Template Library Page
function tlp_template_library_page() {
    ?>
    <div class="wrap tlp-library">
        <h1 class="tlp-main-title">Template Library</h1>
        <div class="tlp-content">
            <div class="tlp-sidebar">
                <h2>Categories</h2>
                <ul id="tlp-category-list">
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="all" checked /> All Templates</li>
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="food-app" /> Food App</li>
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="digital-marketing" /> Digital Marketing App</li>
                </ul>
            </div>
            <div id="tlp-template-display" class="tlp-template-display">
                <h2>All Templates</h2>
                <!-- Templates will be loaded here via JavaScript -->
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Load templates for the "All Templates" category on initial load
            loadTemplates(['all']);

            document.querySelectorAll('.tlp-category-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', function () {
                    const selectedCategories = Array.from(document.querySelectorAll('.tlp-category-checkbox:checked'))
                        .map(cb => cb.getAttribute('data-category'));
                    loadTemplates(selectedCategories);
                });
            });

            // Add event listeners for popup functionality
            document.addEventListener('click', function (e) {
                if (e.target.classList.contains('tlp-template-image')) {
                    const imgSrc = e.target.src; // Get the image source
                    showPopup(imgSrc); // Call function to show popup
                }
            });
        });

        function loadTemplates(categories) {
            let templateFiles = categories.map(category => {
                if (category === 'food-app') return '<?php echo plugin_dir_url(__FILE__); ?>templates/food-app.json';
                if (category === 'digital-marketing') return '<?php echo plugin_dir_url(__FILE__); ?>templates/digital-marketing.json';
                return '<?php echo plugin_dir_url(__FILE__); ?>templates/all-templates.json';
            });

            Promise.all(templateFiles.map(file => fetch(file).then(response => response.json())))
                .then(data => {
                    const allTemplates = data.flatMap(fileData => fileData.templates);
                    console.log(allTemplates); // Debugging log
                    const uniqueTemplates = Array.from(new Set(allTemplates.map(template => template.name)))
                        .map(name => allTemplates.find(template => template.name === name));

                    displayTemplates(uniqueTemplates);
                });
        }

        function displayTemplates(templates) {
            let output = '<ul class="tlp-template-list">';
            templates.forEach(template => {
                output += `
                    <li class="tlp-template-item">
                        <div class="tlp-image-container">
                            <img src="${template.image}" alt="${template.name}" class="tlp-template-image"/><br>
                            <span class="tlp-hover-text">View</span>
                        </div>
                        <strong>${template.name}</strong><br>
                        <a href="${template.download}" class="button button-primary">Download JSON</a>
                    </li>`;
            });
            output += '</ul>';
            document.getElementById('tlp-template-display').innerHTML = output;
        }

        // Function to show the popup
        function showPopup(imgSrc) {
            const popupOverlay = document.createElement('div');
            popupOverlay.className = 'popup-overlay';
            popupOverlay.innerHTML = `
                <img src="${imgSrc}" alt="Popup Image" />
            `;
            document.body.appendChild(popupOverlay);

            // Show the popup
            popupOverlay.classList.add('show');

            // Hide the popup when clicked
            popupOverlay.addEventListener('click', function () {
                popupOverlay.classList.remove('show');
                document.body.removeChild(popupOverlay); // Remove from DOM
            });
        }
    </script>

    



    <?php
}
