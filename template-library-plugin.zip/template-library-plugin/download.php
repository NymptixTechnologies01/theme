<?php
// download.php

// Ensure this file is being called from the WordPress context
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Check if the 'file' parameter is set
if (isset($_GET['file'])) {
    $file = basename($_GET['file']); // Sanitize the file name
    $filepath = get_template_directory() . '/templates/' . $file; // Update this to the correct path

    // Check if the file exists
    if (file_exists($filepath)) {
        // Set headers to trigger the download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        
        // Clear output buffer
        ob_clean();
        flush();

        // Read the file and send it to the output
        readfile($filepath);
        exit;
    } else {
        // File doesn't exist
        header('Content-Type: application/json');
        echo json_encode(['error' => 'File not found.']);
        exit;
    }
} else {
    // No file parameter set
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No file specified.']);
    exit;
}
