<?php
/**
 * Plugin Name: Template Library Plugin
 * Description: A plugin to manage a library of templates with download functionality.
 * Version: 1.2
 * Author: Your Name
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue styles and scripts
function tlp_enqueue_scripts() {
    wp_enqueue_style('tlp-style', plugin_dir_url(__FILE__) . 'assets/style.css');
}
add_action('admin_enqueue_scripts', 'tlp_enqueue_scripts');

// Create the admin menu
function tlp_create_menu() {
    add_menu_page('Template Library', 'Template Library', 'manage_options', 'template-library', 'tlp_template_library_page');
}
add_action('admin_menu', 'tlp_create_menu');

// Template Library Page
function tlp_template_library_page() {
    ?>
    <div class="wrap tlp-library">
        <h1 class="tlp-main-title">Template Library</h1>
        <div class="tlp-content">
            <div class="tlp-sidebar">
                <h2>Categories</h2>
                <ul id="tlp-category-list">
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="all" checked /> All Templates</li>
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="food-app" /> Food App</li>
                    <li><input type="checkbox" class="tlp-category-checkbox" data-category="digital-marketing" /> Digital Marketing App</li>
                </ul>
            </div>
            <div id="tlp-template-display" class="tlp-template-display">
                <div class="tlp-search-container">
                    <input type="text" id="tlp-search-bar" placeholder="Search templates..." />
                </div>
                <ul class="tlp-template-list"></ul>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Load templates for the "All Templates" category on initial load
            loadTemplates(['all']);

            // Handle category changes
            document.querySelectorAll('.tlp-category-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', function () {
                    const selectedCategories = Array.from(document.querySelectorAll('.tlp-category-checkbox:checked'))
                        .map(cb => cb.getAttribute('data-category'));
                    loadTemplates(selectedCategories);
                });
            });

            // Event listener for template image popup
            document.addEventListener('click', function (e) {
                if (e.target.classList.contains('tlp-template-image')) {
                    const imgSrc = e.target.src; // Get the image source
                    showPopup(imgSrc); // Call function to show popup
                }
            });

            // Event listener for search functionality
            const searchBar = document.getElementById('tlp-search-bar');
            searchBar.addEventListener('input', function () {
                const searchQuery = searchBar.value.toLowerCase();
                const displayedTemplates = document.querySelectorAll('.tlp-template-item');
                displayedTemplates.forEach(template => {
                    const templateName = template.querySelector('strong').textContent.toLowerCase();
                    template.style.display = templateName.includes(searchQuery) ? '' : 'none';
                });
            });
        });

        function loadTemplates(categories) {
            let templateFiles = categories.map(category => {
                if (category === 'food-app') return '<?php echo plugin_dir_url(__FILE__); ?>templates/food-app.json';
                if (category === 'digital-marketing') return '<?php echo plugin_dir_url(__FILE__); ?>templates/digital-marketing.json';
                return '<?php echo plugin_dir_url(__FILE__); ?>templates/all-templates.json';
            });

            Promise.all(templateFiles.map(file => fetch(file).then(response => response.json())))
                .then(data => {
                    const allTemplates = data.flatMap(fileData => fileData.templates);
                    console.log(allTemplates); // Debugging log
                    const uniqueTemplates = Array.from(new Set(allTemplates.map(template => template.name)))
                        .map(name => allTemplates.find(template => template.name === name));

                    displayTemplates(uniqueTemplates);
                });
        }

        function displayTemplates(templates) {
            let output = '<ul class="tlp-template-list">';
            templates.forEach(template => {
                output += `
                    <li class="tlp-template-item">
                        <div class="tlp-image-container">
                            <img src="${template.image}" alt="${template.name}" class="tlp-template-image"/><br>
                            <span class="tlp-hover-text">View</span>
                        </div>
                        <strong>${template.name}</strong><br>
                        <a href="${template.download}" class="button button-primary">Download JSON</a>
                    </li>`;
            });
            output += '</ul>';
            document.querySelector('.tlp-template-list').innerHTML = output; // Insert templates here

            // Apply column layout
            if (templates.length > 0) {
                document.querySelector('.tlp-template-list').style.display = 'contents'; // Change to grid layout
                document.querySelector('.tlp-template-list').style.gridTemplateColumns = 'repeat(3, 1fr)'; // three columns
                document.querySelector('.tlp-template-list').style.gap = '20px'; // Adjust the gap between items
            }
        }

        // Function to show the popup
        function showPopup(imgSrc) {
            const popupOverlay = document.createElement('div');
            popupOverlay.className = 'popup-overlay';
            popupOverlay.innerHTML = `
                <img src="${imgSrc}" alt="Popup Image" />
            `;
            document.body.appendChild(popupOverlay);

            // Show the popup
            popupOverlay.classList.add('show');

            // Hide the popup when clicked
            popupOverlay.addEventListener('click', function () {
                popupOverlay.classList.remove('show');
                document.body.removeChild(popupOverlay); // Remove from DOM
            });
        }
    </script>

    <style>
        .tlp-content {
            display: flex; /* Flexbox layout for sidebar and template display */
        }
        
        .tlp-sidebar {
            width: 20%; /* Sidebar width */
            margin-right: 20px; /* Space between sidebar and templates */
        }
        
        .tlp-template-display {
            flex: 1; /* Fill remaining space */
        }

        .tlp-search-container {
            margin-bottom: 20px; /* Space below search bar */
            margin-left: 1160px;
            margin-top: 20px
        }

        .tlp-template-list {
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
            margin: 0; /* Remove margin */
            display: grid; /* Use grid for layout */
            grid-template-columns: repeat(3, 1fr); /* Four columns */
            gap: 20px; /* Space between items */
        }

        #tlp-search-bar {
            padding: 0 8px;
            line-height: 2;
            min-height: 30px;
            font-size: 18px;
        }

        .tlp-template-item {
            border: 1px solid #ccc; /* Add a border */
            padding: 10px; /* Add padding */
            text-align: center; /* Center text */
            border-radius: 5px; /* Round corners */
            background: #f9f9f9; /* Light background */
            transition: transform 0.2s; /* Add transition for hover effect */
        }
        
        .tlp-template-item:hover {
            transform: scale(1.05); /* Slightly enlarge on hover */
        }
        
        .tlp-image-container {
            cursor: pointer; /* Change cursor on image hover */
        }

        .tlp-hover-text {
        position: relative;
        bottom: 95px;
        transform: translateX(-50%);
        background-color: #1d2327;
        color: white;
        padding: 15px;
        border-radius: 5px;
        opacity: 0;
        transition: opacity 0.3s ease;
        left: 182px;
}
.popup-overlay {
  display: none; /* Hidden by default */
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  justify-content: center;
  align-items: center;
  z-index: 1000; /* Above other elements */
}

.popup-overlay img {
  max-width: 70%; /* Adjust maximum width of popup image */
  max-height: 70%; /* Adjust maximum height of popup image */
  border: 5px solid white; /* Optional styling */
}

        .popup-overlay.show {
            opacity: 1; /* Show the overlay */
        }

      
    </style>
    
    <?php
}
